package com.example.proyecto;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ComentarioActivity extends AppCompatActivity {

    private Intent intent ;
    private String usuario;
    private Spinner spinnerTiempo, spinnerImpacto,spinnerTipoImpacto;
    private Button comentario;
    private boolean comentarios_guardado = true;

    RequestQueue requestQueue;

    private static String server;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comentario);

        requestQueue = Volley.newRequestQueue(this);

        server = "http://"+getResources().getString(R.string.ipTxt)+"/android/reportes.php";

        intent = getIntent();
        usuario = intent.getStringExtra("usuario");


        spinnerTiempo = (Spinner) findViewById(R.id.Tipotiempo);
        String[] opciones = {"Horas","Dias","Meses","Años"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        spinnerTiempo.setAdapter(adapter);

        spinnerTipoImpacto = (Spinner) findViewById(R.id.TipoReporte);
        String[] opciones3 = {"Señal Dañada","Vial en mal estado","Semaforo Dañado","Otro"};
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones3);
        spinnerTipoImpacto.setAdapter(adapter3);

        spinnerImpacto = (Spinner) findViewById(R.id.Impacto);
        String[] opciones2;
        opciones2 = new String[]{"1","2","3","4","5","6","7","8","9","10"};
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones2);
        spinnerImpacto.setAdapter(adapter2);

        comentario = findViewById(R.id.reportar);
        comentario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(verificarDatos()){
                    Intent abd = new Intent(ComentarioActivity.this, InicioActivity.class);
                    startActivities(new Intent[]{abd});
                }
            }
        });

    }

    public Boolean verificarDatos() {
        Spinner stipoRe = (Spinner) findViewById(R.id.TipoReporte);
        String tipoRe = stipoRe.getSelectedItem().toString();
        Spinner simpacto = (Spinner) findViewById(R.id.Impacto);
        String impacto = simpacto.getSelectedItem().toString();

        String tiempo = String.valueOf(((EditText)findViewById(R.id.tiempo)).getText());


        Spinner tipoTi = (Spinner) findViewById(R.id.Tipotiempo);
        String tipoTiempo= tipoTi.getSelectedItem().toString();
        String Direccion = String.valueOf(((EditText)findViewById(R.id.Comentario_Direccion)).getText());
        String descripcion = String.valueOf(((EditText)findViewById(R.id.Descripcion)).getText());


        if(tipoRe.equals("") || impacto.equals("") || tiempo.equals("") || Direccion.equals("") || tipoTiempo.equals("") || descripcion.equals("")){
            Toast.makeText(ComentarioActivity.this,"TODOS LOS CAMPOS TIENEN QUE ESTAR LLENOS",Toast.LENGTH_LONG).show();
            return false;
        }else
        {
            char[] tiempoSep = tiempo.toCharArray();

            for (char c : tiempoSep) {
                if (Character.isDigit(c)) {
                    return false;
                }
            }
        }
        System.out.println("Subiendo....");
        subirComentario(tipoRe,impacto,tiempo,descripcion,"0","0");

        return true;
    }



    private void subirComentario(final String Calamidad,final String Impacto,final String Tiempo,final String Descripccion,final String Lat,final String Lon) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                server,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(ComentarioActivity.this,"SU COMENTARIO SE A GUARDADO",Toast.LENGTH_SHORT);
                        System.out.println("Comentario Guardado");
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ComentarioActivity.this,"U COMENTARIO NO SE A GUARDADO",Toast.LENGTH_SHORT);
                        System.out.println("Comentario Fallo");
                    }
                }

        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> param = new HashMap<>();
                param.put("CALAMIDAD",Calamidad);
                param.put("IMPACTO",Impacto);
                param.put("TIEMPO", Tiempo);
                param.put("DESCRIPCCION",Descripccion);
                param.put("LAT",Lat);
                param.put("LON",Lon);
                return param;
            }
        };

        requestQueue.add(stringRequest);
    }




}