package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class formularioalerta extends AppCompatActivity {

    Button subir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formularioalerta);

        subir = findViewById(R.id.subiralerta);
        subir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cdf = new Intent(formularioalerta.this, InicioActivity.class);
                startActivities(new Intent[]{cdf});
            }
        });
    }
}